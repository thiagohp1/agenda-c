typedef struct {
    int dia,mes,ano;
}Data;

typedef struct {
    int hora,minuto;
}Hora;

typedef struct {
    Data data;
    Hora inicio;
    Hora fim;
    char descricao[50];
    char local[50];
}Evento;



