#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Lista.h"
#include "agenda.h"


int main(int argc, char *argv[]) {
    int op;
    Lista *listaEvento;
    Evento evento;
    
    inicializa_lista(listaEvento, sizeof(evento));

    printf("Agenda\n 1.Cadastrar um novo evento. \n 2.Mostrar todos os eventos da agenda. \n 3.Mostrar todos os eventos dessa data. \n 4.Mostrar todos os eventos que tenham essa descrição. \n 5.Remover evento.\n 6. Salvar e sair");
    scanf("%d", &op);


    switch (op)
    {
    case(1):
    
        break;

    case(2):
        
        break;

    case(3):
        
        break;

    case(4):
        
        break;
                
    case(5):
        
        break;
    default:
        break;
    }



}




